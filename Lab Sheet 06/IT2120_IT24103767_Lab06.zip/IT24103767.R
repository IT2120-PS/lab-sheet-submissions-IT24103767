#Q1
#Binomial Distribution
1-pbinom(47,50,0.85,lower.tail = TRUE)-pbinom(47,50,0.85,lower.tail = FALSE)
#Q2
#i X= No of customer calls received in an hour
#ii Poisson Distribution
#iii
dpois(15,12)
